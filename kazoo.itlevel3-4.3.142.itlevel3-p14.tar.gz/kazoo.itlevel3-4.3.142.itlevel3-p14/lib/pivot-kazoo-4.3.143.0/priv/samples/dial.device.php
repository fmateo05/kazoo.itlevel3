<?php
    header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>
<Response>
    <Dial>
        <Device>
            8df638a7a4a4d2bd8eca37f47f30abfc
        </Device>
    </Dial>
    <Say>Goodbye</Say>
</Response>