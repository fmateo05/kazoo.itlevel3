<?php
    header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>
<Response>
    <Dial>
        <Sip>user@host.com:2600</Sip>
    </Dial>
    <Say>Goodbye</Say>
</Response>