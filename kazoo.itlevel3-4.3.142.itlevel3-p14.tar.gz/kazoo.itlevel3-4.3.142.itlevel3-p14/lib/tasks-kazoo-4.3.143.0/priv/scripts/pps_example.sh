#!/bin/sh

echo "Post processing csv file: $1"
mv $1 $1_processed
echo "done"
